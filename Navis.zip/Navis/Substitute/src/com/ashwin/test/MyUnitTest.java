/**
 * 
 */
package com.ashwin.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.ashwin.java.CustomException;
import com.ashwin.java.StringSub;

/**
 * @author AshwinSakthi
 *
 */
public class MyUnitTest {

	@Test
	public void testSingleExpr() throws CustomException {
		Map<String, String> valuesMap = new HashMap<String, String>();

		valuesMap.put("name", "Cenk");
		

		String templateString = "Hello {$name}";
		
		StringSub sb =new StringSub();
		assert(sb.substitutStr(valuesMap, templateString).equalsIgnoreCase("Hello Cenk"));
		
	}
	
	@Test
	public void testMultExpr() throws CustomException {
		Map<String, String> valuesMap = new HashMap<String, String>();

		valuesMap.put("firstName","Cenk");
		valuesMap.put("lastName","Civici");

		

		String templateString = "Hello {$firstName} ${lastName}";
		
		StringSub sb =new StringSub();
		assert(sb.substitutStr(valuesMap, templateString).equalsIgnoreCase("Hello CenkCivici"));
		
	}
	
	
	@Test
	public void testComplexCase() throws CustomException {
		Map<String, String> valuesMap = new HashMap<String, String>();

		valuesMap.put("name","Cenk");
		

		

		String templateString = "Hello ${$name}}";
		
		StringSub sb =new StringSub();
		assert(sb.substitutStr(valuesMap, templateString).equalsIgnoreCase("Hello CenkCivici"));
		
	}

}

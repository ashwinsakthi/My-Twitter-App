package com.ashwin.java;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.text.StrMatcher;
import org.apache.commons.lang.text.StrSubstitutor;

/**
 * @author AshwinSakthi
 *
 */
public class StringSub {
	public static void main(String[] args) {	

		// public static final char DEFAULT_ESCAPE = '$';
		// public static final StrMatcher DEFAULT_PREFIX =
		// StrMatcher.stringMatcher("${");
		// public static final StrMatcher DEFAULT_SUFFIX =
		// StrMatcher.stringMatcher("}");
		/*
		 * public StrSubstitutor(Map valueMap, String prefix, String suffix,
		 * char escape) { this(StrLookup.mapLookup(valueMap), prefix, suffix,
		 * escape); }
		 */

		try {
			
			Map<String, String> valuesMap = new HashMap<String, String>();

/*			valuesMap.put("name", "Cenk");
			valuesMap.put("target", "lazy dog");

			String templateString = "Hello {$name}";*/
			
			valuesMap.put("firstName","Cenk");
			valuesMap.put("lastName","Civici");

			

			String templateString = "Hello {$firstName} ${lastName}";
			
			new StringSub().substitutStr(valuesMap, templateString);
			
		} catch (CustomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * @param valuesMap
	 * @param templateString
	 * @throws CustomException
	 */
	public String substitutStr(Map<String, String> valuesMap, String templateString) throws CustomException {

		if(valuesMap == null || templateString ==null || templateString.trim().length()==0){
			throw new CustomException("Template variable does not exist in the map");
		}
		
		StrSubstitutor defaultSub = new StrSubstitutor(valuesMap);

		StrSubstitutor customSub = new StrSubstitutor(valuesMap, "{$", "}", '{');

		String finalString = null;


		if (defaultSub.replace(templateString).contains("$")) {
			System.out.println(defaultSub.replace(templateString).contains("$"));
			if (customSub.replace(templateString).contains("$")) {
				 System.out.println(customSub.replace(templateString));
				System.out.println("Throw Error");
				throw new CustomException("Template variable does not exist in the map");
			} else {
				System.out.println("String Processed");
				finalString = customSub.replace(templateString);
				// System.out.println(customSub.replace(templateString).contains("$"));
			}

		} else {
			System.out.println("String Processed");
			// System.out.println(defaultSub.replace(templateString).contains("$"));
			finalString = defaultSub.replace(templateString);
		}
		
		
		return finalString;
	}


}

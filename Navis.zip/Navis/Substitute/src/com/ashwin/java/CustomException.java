package com.ashwin.java;

public class CustomException extends Exception {
	CustomException(String s){  
		  super(s);  
		 } 
}
